#!/usr/bin/env bash

# Copies documentation to blog
cp -R build/docs/html/. ../blog/public/documentation/
